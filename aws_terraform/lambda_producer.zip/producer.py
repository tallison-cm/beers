import json, urllib3
import boto3

access_key = 'AKIATRDMCSYHFEST2BUL'
secret_access_key = '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'
region = 'sa-east-1'
stream_name = 'beers-stream'

def lambda_handler(event, context):
    http = urllib3.PoolManager()
    resp = http.request('GET', 'https://api.punkapi.com/v2/beers/random')
    json_resp = json.loads(resp.data.decode('utf-8'))[0]
    
    kinesis = boto3.client('kinesis', aws_access_key_id=access_key, aws_secret_access_key=secret_access_key, region_name=region)
    kinesis.put_record(StreamName=stream_name, Data=json.dumps(json_resp), PartitionKey='beers')

