import json
import boto3
import base64

def stringToBase64(str_to_encode):
    return base64.b64encode(str_to_encode.encode('utf-8'))
    
def base64ToString(str64):
    return base64.b64decode(str64).decode('utf-8')

def get_cleaned(raw):
    json_raw = json.loads(raw)
    clean_rec = {
        'id': json_raw['id'],
        'name': json_raw['name'],
        'abv': json_raw['abv'],
        'ibu': json_raw['ibu'],
        'target_fg': json_raw['target_fg'],
        'target_og': json_raw['target_og'],
        'ebc': json_raw['ebc'],
        'srm': json_raw['srm'],
        'ph': json_raw['ph']
    }
    
    return json.dumps(clean_rec)

def lambda_handler(event, context):
    output = []

    for record in event['records']:
        print(record['recordId'])
        payload = base64ToString(record['data'])
        cleaned_record = get_cleaned(payload)

        output_record = {
            'recordId': record['recordId'],
            'result': 'Ok',
            'data': stringToBase64(cleaned_record)
        }
        output.append(output_record)

    print('Successfully processed {} records.'.format(len(event['records'])))

    return {'records': output}
